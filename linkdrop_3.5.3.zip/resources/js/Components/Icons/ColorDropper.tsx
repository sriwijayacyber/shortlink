import { SVGProps } from "react-html-props";

const ColorDropper = (props: SVGProps) => {
   return (
      <svg
         xmlns="http://www.w3.org/2000/svg"
         height="1em"
         viewBox="0 0 512 512"
         {...props}
      >
         <path
            fill="currentColor"
            d="M341.6 29.2L240.1 130.8l-9.4-9.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l160 160c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3l-9.4-9.4L482.8 170.4c39-39 39-102.2 0-141.1s-102.2-39-141.1 0zM143.4 411.3L234.7 320H149.3l-48.6 48.6c-3 3-4.7 7.1-4.7 11.3V416h36.1c4.2 0 8.3-1.7 11.3-4.7z"
         />
         <path
            fill="currentColor"
            style={{ opacity: 0.4 }}
            d="M198.7 180L55.4 323.3c-15 15-23.4 35.4-23.4 56.6v42.4L5.4 462.2c-8.5 12.7-6.8 29.6 4 40.4s27.7 12.5 40.4 4L89.7 480h42.4c21.2 0 41.6-8.4 56.6-23.4L332 313.3 286.7 268 143.4 411.3c-3 3-7.1 4.7-11.3 4.7H96V379.9c0-4.2 1.7-8.3 4.7-11.3L244 225.3 198.7 180z"
         />
      </svg>
   );
};

export default ColorDropper;
