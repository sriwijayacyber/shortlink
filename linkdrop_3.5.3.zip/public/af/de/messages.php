<?php

return [

    'title' => "Dies ist ein englischsprachiger Titel.",

];
