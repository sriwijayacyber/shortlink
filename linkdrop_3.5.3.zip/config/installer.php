<?php

return [
    'app_id' => '43555815',

    'tmp_folder' => 'tmp',

    'script_file' => 'upgrade.php',

    'app_update_url' => 'https://custaid.getstocky.com/api/current-version-app',

    'app_version_url' => 'https://custaid.getstocky.com/api/current-version',

    'verify_purchase_url' => 'https://custaid.getstocky.com/api/verify-purchase',
];
